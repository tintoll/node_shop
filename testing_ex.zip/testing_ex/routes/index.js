var express = require('express');
var router = express.Router();
var ProductsModel = require('../models/ProductsModel');

router.get('/', function(req,res){
    ProductsModel.find( function(err,products){
        res.render( 'list' , 
            { products : products } 
        );
    });
});

router.get('/write', function(req,res){
    res.render( 'form' , { product : "" }); 
});

router.post('/write', function(req,res){
    var product = new ProductsModel({
        name : req.body.name,
        description : req.body.description,
    });
    product.save(function(err){
        res.redirect('/');
    });
});

router.get('/detail/:id' , function(req, res){
    ProductsModel.findOne( function(err,product){
        res.render( 'detail' , { product : product });
    });
});

router.get('/edit/:id' ,function(req, res){
    ProductsModel.findOne({ id : req.params.id } , function(err, product){
        res.render('form', { product : product });
    });
});

router.post('/edit/:id', function(req, res){
    var query = {
        name : req.body.name,
        description : req.body.description,
    };

    ProductsModel.update({ id : req.params.id }, { $set : query }, function(err){
        res.redirect('/detail/' + req.params.id );
    });
});

router.get('/delete/:id', function(req, res){
    ProductsModel.remove({ id : req.params.id }, function(err){
        res.redirect('/');
    });
});

module.exports = router;